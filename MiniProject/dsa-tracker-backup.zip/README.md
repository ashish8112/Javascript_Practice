# ⚡ DSATracker — Spaced Repetition for Coders

> A full-stack Next.js 14 app deployed on Vercel + Supabase. 100% free tier.

## Features
- 🔐 Google OAuth + Email/Password auth
- 📅 Spaced repetition: Day +3, +7, +15, +30
- 🔥 Daily streak + GitHub-style activity heatmap  
- 🎯 Difficulty tagging (Easy / Medium / Hard)
- 📝 Notes/approach per question
- 🔗 LeetCode link attachment
- 🔍 Search + filter by topic + difficulty
- ✅ Bulk "mark all revised" shortcut
- 🎉 Confetti on mastering a question
- 📊 Topic & difficulty breakdown charts
- 📱 Mobile-first, works on any device

## Stack (all free)
| Layer    | Tech              | Free Tier          |
|----------|-------------------|--------------------|
| Frontend | Next.js 14        | Vercel (unlimited) |
| Database | PostgreSQL        | Supabase (500MB)   |
| Auth     | Supabase Auth     | 50,000 MAU free    |
| Hosting  | Vercel            | Free hobby plan    |

## Setup

### 1. Supabase
1. Create project at supabase.com
2. Go to **SQL Editor** → paste `SUPABASE_SETUP.sql` → Run
3. Go to **Authentication → Providers → Google** → Enable, add Client ID + Secret
4. Add redirect URL: `https://YOUR-VERCEL-URL.vercel.app/auth/callback`

### 2. Deploy to Vercel
```bash
# Push to GitHub first
git init && git add . && git commit -m "init"
gh repo create dsa-tracker --public --push

# Then on vercel.com → New Project → import repo
# Add env vars:
# NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
# NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
```

### 3. Local Development
```bash
npm install
cp .env.local.example .env.local  # fill in your keys
npm run dev
```

## Rate Limit Fix
Email signup is rate-limited to 4/hour on Supabase free tier.
**Solution:** Use Google OAuth — zero email needed, unlimited signups.
