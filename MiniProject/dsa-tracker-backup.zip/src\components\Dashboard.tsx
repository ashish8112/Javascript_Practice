'use client'

import { useState, useMemo } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { useQuestions } from '@/hooks/useQuestions'
import { useActivity } from '@/hooks/useActivity'
import { useToast } from '@/components/Toast'
import QuestionCard from '@/components/QuestionCard'
import AddQuestionModal from '@/components/AddQuestionModal'
import EditQuestionModal from '@/components/EditQuestionModal'
import ActivityHeatmap from '@/components/ActivityHeatmap'
import StatsPanel from '@/components/StatsPanel'
import NotificationSettings from '@/components/NotificationSettings'
import { todayLocal } from '@/lib/dates'
import { TOPICS, DIFFICULTY_CONFIG, type Topic } from '@/types'
import {
  Plus, LogOut, Zap, Search, SlidersHorizontal,
  CheckCheck, LayoutDashboard, BarChart3, X
} from 'lucide-react'

type View = 'dashboard' | 'stats'

export default function Dashboard() {
  const { user, signOut } = useAuth()
  const { questions, loading, addQuestion, markRevised, deleteQuestion, updateNotes, updateQuestion, bulkMarkRevised, refetch } = useQuestions()
  const { activityMap, streak, totalRevisions } = useActivity()
  const { show: showToast, ToastContainer } = useToast()

  const [showAdd, setShowAdd]           = useState(false)
  const [editQuestion, setEditQuestion] = useState<import('@/types').Question | null>(null)
  const [view, setView]                 = useState<View>('dashboard')
  const [search, setSearch]             = useState('')
  const [filterTopic, setFilterTopic]   = useState<Topic | 'All'>('All')
  const [filterDiff, setFilterDiff]     = useState<'All' | 'Easy' | 'Medium' | 'Hard'>('All')
  const [showFilters, setShowFilters]   = useState(false)
  const [confettiFired, setConfettiFired] = useState(false)

  const today = todayLocal()

  const fireConfetti = async () => {
    if (confettiFired) return
    setConfettiFired(true)
    const confetti = (await import('canvas-confetti')).default
    confetti({ particleCount: 150, spread: 90, origin: { y: 0.6 }, colors: ['#5b8cff', '#a78bfa', '#34d399', '#fbbf24'] })
    setTimeout(() => setConfettiFired(false), 3000)
  }

  const handleRevise = async (id: string, stage: number) => {
    const err = await markRevised(id, stage)
    if (err) { showToast('⚠️ ' + err, 'error'); return }
    const nextStage = stage + 1
    if (nextStage >= 4) { showToast('🎓 Mastered! All 4 stages complete!', 'success'); fireConfetti() }
    else { showToast(`✅ Revised! Next up in ${[7, 15, 30][nextStage - 1] ?? '?'} days`, 'success') }
  }

  const handleAdd = async (payload: Parameters<typeof addQuestion>[0]) => {
    const err = await addQuestion(payload)
    if (!err) showToast('✅ Question logged & scheduled!', 'success')
    return err
  }

  const handleDelete = async (id: string) => {
    await deleteQuestion(id)
    showToast('🗑️ Removed', 'info')
  }

  const handleBulkRevise = async () => {
    const dueIds = dueQuestions.map(q => q.id)
    if (!dueIds.length) return
    await bulkMarkRevised(dueIds)
    showToast(`✅ Marked ${dueIds.length} questions as revised!`, 'success')
  }

  const dueQuestions = useMemo(() =>
    questions.filter(q => q.next_revision_date !== 'Completed' && q.next_revision_date <= today),
    [questions, today]
  )

  const filteredAll = useMemo(() =>
    questions.filter(q => {
      const matchSearch = !search || q.name.toLowerCase().includes(search.toLowerCase())
      const matchTopic  = filterTopic === 'All' || q.topic === filterTopic
      const matchDiff   = filterDiff  === 'All' || q.difficulty === filterDiff
      return matchSearch && matchTopic && matchDiff
    }),
    [questions, search, filterTopic, filterDiff]
  )

  const hasFilters = !!(search || filterTopic !== 'All' || filterDiff !== 'All')

  const clearFilters = () => { setSearch(''); setFilterTopic('All'); setFilterDiff('All') }

  return (
    <div className="min-h-screen bg-[#0d0f14] text-white"
      style={{
        backgroundImage: 'linear-gradient(rgba(91,140,255,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(91,140,255,0.03) 1px,transparent 1px)',
        backgroundSize: '40px 40px'
      }}>
      <ToastContainer />
      {showAdd && <AddQuestionModal onAdd={handleAdd} onClose={() => setShowAdd(false)} />}
      {editQuestion && (
        <EditQuestionModal
          question={editQuestion}
          onSave={async (id: string, payload: {name: string; topic: string; difficulty: string; lc_link: string; notes: string}) => {
            const err = await updateQuestion(id, payload)
            if (!err) showToast('✅ Question updated!', 'success')
            return err
          }}
          onClose={() => setEditQuestion(null)}
        />
      )}

      {/* ── HEADER ── */}
      <header className="sticky top-0 z-40 bg-[#0d0f14]/95 backdrop-blur-md border-b border-[#2a3040]">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center">
              <Zap size={14} className="text-white" />
            </div>
            <span className="font-black text-base font-mono">DSA<span className="text-blue-400">Tracker</span></span>
          </div>
          <div className="flex items-center gap-2">
            {/* Streak badge */}
            {streak > 0 && (
              <span className="text-xs font-bold text-amber-400 bg-amber-400/10 border border-amber-400/20 rounded-full px-2.5 py-1">
                🔥 {streak} day{streak > 1 ? 's' : ''}
              </span>
            )}
            {/* Username */}
            <span className="text-[11px] text-[#6b7a99] hidden sm:block max-w-[110px] truncate">
              {user?.email?.split('@')[0]}
            </span>
            {/* Logout */}
            <button onClick={signOut} title="Sign out"
              className="text-[#6b7a99] hover:text-red-400 transition-colors p-1.5 rounded-lg hover:bg-red-400/10">
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </header>

      {/* ── DESKTOP TABS (hidden on mobile — using bottom nav instead) ── */}
      <div className="hidden sm:block max-w-2xl mx-auto px-4 pt-4">
        <div className="flex gap-1 bg-[#161a23] border border-[#2a3040] rounded-xl p-1 mb-4">
          {([
            { id: 'dashboard', label: 'Dashboard',      icon: LayoutDashboard },
            { id: 'stats',     label: 'Stats & Activity', icon: BarChart3 },
          ] as const).map(tab => (
            <button key={tab.id} onClick={() => setView(tab.id)}
              className={`flex-1 flex items-center justify-center gap-2 rounded-lg py-2 text-sm font-bold transition-all ${
                view === tab.id ? 'bg-blue-500 text-white' : 'text-[#6b7a99] hover:text-white'
              }`}>
              <tab.icon size={15} />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── MAIN CONTENT ── */}
      <main className="max-w-2xl mx-auto px-4 pt-4 sm:pt-0 pb-28 sm:pb-20">

        {/* ══════ DASHBOARD VIEW ══════ */}
        {view === 'dashboard' && (
          <div className="space-y-4">

            {/* ── Due Today ── */}
            <div className="bg-[#161a23] border border-[#2a3040] rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between p-4 pb-3">
                <div>
                  <h2 className="font-black text-white text-base flex items-center gap-2">
                    🔥 Due Today
                    <span className={`text-sm font-mono px-2 py-0.5 rounded-full ${
                      dueQuestions.length > 0 ? 'bg-amber-400/10 text-amber-400' : 'bg-[#2a3040] text-[#6b7a99]'
                    }`}>{dueQuestions.length}</span>
                  </h2>
                  <p className="text-[11px] text-[#6b7a99] mt-0.5">
                    {dueQuestions.length === 0
                      ? "All caught up — great work! 🎉"
                      : `${dueQuestions.length} question${dueQuestions.length > 1 ? 's' : ''} waiting for revision`}
                  </p>
                </div>
                {dueQuestions.length > 1 && (
                  <button onClick={handleBulkRevise}
                    className="flex items-center gap-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 active:scale-95 border border-emerald-500/30 text-emerald-400 rounded-xl px-3 py-2 text-xs font-bold transition-all">
                    <CheckCheck size={14} />
                    All Done
                  </button>
                )}
              </div>

              <div className="px-4 pb-4">
                {loading ? (
                  <div className="space-y-2">
                    {[1,2].map(i => <div key={i} className="h-20 bg-[#1e2330] rounded-xl animate-pulse" />)}
                  </div>
                ) : dueQuestions.length === 0 ? (
                  <div className="text-center py-8 border border-dashed border-[#2a3040] rounded-xl bg-[#1a1f2b]/50">
                    <div className="text-4xl mb-2">🎯</div>
                    <p className="text-white font-bold text-sm">Nothing due today</p>
                    <p className="text-[#6b7a99] text-xs mt-1">Come back tomorrow or add more questions</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {dueQuestions.map(q => (
                      <QuestionCard key={q.id} question={q}
                        onRevise={handleRevise} onDelete={handleDelete}
                        onEdit={setEditQuestion} onUpdateNotes={updateNotes} refetch={refetch} />
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* ── All Questions ── */}
            <div className="bg-[#161a23] border border-[#2a3040] rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between p-4 pb-3">
                <h2 className="font-black text-white text-base flex items-center gap-2">
                  📋 All Questions
                  <span className="text-sm font-mono px-2 py-0.5 rounded-full bg-[#2a3040] text-[#6b7a99]">
                    {filteredAll.length}{hasFilters ? `/${questions.length}` : ''}
                  </span>
                </h2>
                <button onClick={() => setShowFilters(!showFilters)}
                  className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold border transition-all ${
                    hasFilters
                      ? 'bg-blue-500/10 border-blue-500/30 text-blue-400'
                      : 'bg-[#1e2330] border-[#2a3040] text-[#6b7a99] hover:text-white'
                  }`}>
                  <SlidersHorizontal size={13} />
                  Filter
                  {hasFilters && (
                    <span className="bg-blue-500 text-white rounded-full w-4 h-4 text-[10px] flex items-center justify-center font-black">
                      {[search ? 1 : 0, filterTopic !== 'All' ? 1 : 0, filterDiff !== 'All' ? 1 : 0].reduce((a,b)=>a+b,0)}
                    </span>
                  )}
                </button>
              </div>

              <div className="px-4 pb-4 space-y-3">
                {/* Search bar */}
                <div className="relative">
                  <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#6b7a99]" />
                  <input
                    value={search} onChange={e => setSearch(e.target.value)}
                    placeholder="Search by question name…"
                    className="w-full bg-[#1e2330] border border-[#2a3040] rounded-xl pl-9 pr-10 py-3 text-sm text-white outline-none focus:border-blue-500 transition-colors placeholder:text-[#6b7a99]"
                  />
                  {search && (
                    <button onClick={() => setSearch('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6b7a99] hover:text-white w-5 h-5 flex items-center justify-center rounded-full hover:bg-[#2a3040] transition-all">
                      <X size={12} />
                    </button>
                  )}
                </div>

                {/* Filter panel */}
                {showFilters && (
                  <div className="bg-[#1e2330] border border-[#2a3040] rounded-xl p-3 space-y-2.5">
                    {/* Topic chips */}
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-[#6b7a99] mb-1.5">Topic</p>
                      <div className="flex gap-1.5 flex-wrap">
                        {(['All', ...TOPICS] as const).map(t => (
                          <button key={t} onClick={() => setFilterTopic(t as Topic | 'All')}
                            className={`text-[11px] font-bold px-2.5 py-1 rounded-full border transition-all ${
                              filterTopic === t
                                ? 'bg-blue-500/15 border-blue-500/40 text-blue-400'
                                : 'bg-[#161a23] border-[#2a3040] text-[#6b7a99] hover:border-[#3d4a60] hover:text-white'
                            }`}>
                            {t}
                          </button>
                        ))}
                      </div>
                    </div>
                    {/* Difficulty chips */}
                    <div>
                      <p className="text-[10px] font-bold uppercase tracking-wider text-[#6b7a99] mb-1.5">Difficulty</p>
                      <div className="flex gap-2">
                        {(['All', 'Easy', 'Medium', 'Hard'] as const).map(d => (
                          <button key={d} onClick={() => setFilterDiff(d)}
                            className={`flex-1 text-xs font-bold py-2 rounded-xl border transition-all ${
                              filterDiff === d
                                ? d === 'All'
                                  ? 'bg-blue-500/15 border-blue-500/40 text-blue-400'
                                  : `${DIFFICULTY_CONFIG[d]?.bg} ${DIFFICULTY_CONFIG[d]?.border} ${DIFFICULTY_CONFIG[d]?.color}`
                                : 'bg-[#161a23] border-[#2a3040] text-[#6b7a99] hover:border-[#3d4a60]'
                            }`}>
                            {d}
                          </button>
                        ))}
                      </div>
                    </div>
                    {hasFilters && (
                      <button onClick={clearFilters}
                        className="text-[11px] text-red-400 hover:text-red-300 font-semibold flex items-center gap-1">
                        <X size={10} /> Clear all filters
                      </button>
                    )}
                  </div>
                )}

                {/* Question list */}
                {loading ? (
                  <div className="space-y-2">
                    {[1,2,3].map(i => <div key={i} className="h-20 bg-[#1e2330] rounded-xl animate-pulse" />)}
                  </div>
                ) : filteredAll.length === 0 ? (
                  <div className="text-center py-10 border border-dashed border-[#2a3040] rounded-xl">
                    <div className="text-4xl mb-2">{hasFilters ? '🔍' : '📭'}</div>
                    <p className="text-white font-bold text-sm">
                      {hasFilters ? 'No questions match' : 'No questions yet'}
                    </p>
                    <p className="text-[#6b7a99] text-xs mt-1">
                      {hasFilters
                        ? <button onClick={clearFilters} className="text-blue-400 underline">Clear filters</button>
                        : 'Tap + to log your first question'
                      }
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredAll.map(q => (
                      <QuestionCard key={q.id} question={q}
                        onRevise={handleRevise} onDelete={handleDelete}
                        onEdit={setEditQuestion} onUpdateNotes={updateNotes} refetch={refetch} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ══════ STATS VIEW ══════ */}
        {view === 'stats' && (
          <div className="space-y-4">
            <div className="bg-[#161a23] border border-[#2a3040] rounded-2xl p-4">
              <h2 className="font-black text-white mb-1 flex items-center gap-2">
                📅 Activity Heatmap
              </h2>
              <p className="text-[11px] text-[#6b7a99] mb-4">Your revision activity over the last 365 days</p>
              <ActivityHeatmap activityMap={activityMap} />
            </div>
            <StatsPanel questions={questions} streak={streak} totalRevisions={totalRevisions} />
            <NotificationSettings />
          </div>
        )}
      </main>

      {/* ── MOBILE BOTTOM NAV ── */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0d0f14]/95 backdrop-blur-md border-t border-[#2a3040]">
        <div className="flex items-center justify-around px-2 h-16">
          <button onClick={() => setView('dashboard')}
            className={`flex flex-col items-center gap-1 px-6 py-2 rounded-xl transition-all ${
              view === 'dashboard' ? 'text-blue-400' : 'text-[#6b7a99]'
            }`}>
            <LayoutDashboard size={20} />
            <span className="text-[10px] font-bold">Dashboard</span>
          </button>

          {/* Centre FAB */}
          <button onClick={() => setShowAdd(true)}
            className="w-14 h-14 -mt-6 bg-blue-500 hover:bg-blue-600 active:scale-95 text-white rounded-full shadow-2xl shadow-blue-500/30 flex items-center justify-center transition-all border-4 border-[#0d0f14]">
            <Plus size={24} />
          </button>

          <button onClick={() => setView('stats')}
            className={`flex flex-col items-center gap-1 px-6 py-2 rounded-xl transition-all ${
              view === 'stats' ? 'text-blue-400' : 'text-[#6b7a99]'
            }`}>
            <BarChart3 size={20} />
            <span className="text-[10px] font-bold">Stats</span>
          </button>
        </div>
      </nav>

      {/* ── DESKTOP FAB ── */}
      <button onClick={() => setShowAdd(true)}
        className="hidden sm:flex fixed bottom-6 right-6 z-40 w-14 h-14 bg-blue-500 hover:bg-blue-600 active:scale-95 text-white rounded-full shadow-2xl items-center justify-center transition-all hover:scale-110">
        <Plus size={24} />
      </button>
    </div>
  )
}