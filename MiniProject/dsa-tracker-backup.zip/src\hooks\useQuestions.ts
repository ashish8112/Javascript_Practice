'use client'

import { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/lib/supabase'
import { Question, INTERVALS } from '@/types'
import { todayLocal, addDays } from '@/lib/dates'
import { useAuth } from './useAuth'

export function useQuestions() {
  const { user } = useAuth()
  const [questions, setQuestions] = useState<Question[]>([])
  const [loading, setLoading] = useState(true)

  const fetch = useCallback(async () => {
    if (!user) return
    setLoading(true)
    const { data } = await supabase
      .from('questions')
      .select('*')
      .order('created_at', { ascending: false })
    setQuestions(data || [])
    setLoading(false)
  }, [user])

  useEffect(() => { fetch() }, [fetch])

  const addQuestion = async (payload: {
    name: string; topic: string; difficulty: string
    date_solved: string; notes: string; lc_link: string
  }) => {
    if (!user) return null
    const { error } = await supabase.from('questions').insert([{
      user_id: user.id,
      ...payload,
      current_stage: 0,
      next_revision_date: addDays(payload.date_solved, INTERVALS[0])
    }])
    if (!error) await fetch()
    return error?.message ?? null
  }

  const markRevised = async (id: string, currentStage: number) => {
    if (currentStage >= INTERVALS.length) return
    const nextStage = currentStage + 1
    const nextDate = nextStage >= INTERVALS.length ? 'Completed' : addDays(todayLocal(), INTERVALS[nextStage])
    const { error } = await supabase
      .from('questions')
      .update({ current_stage: nextStage, next_revision_date: nextDate })
      .eq('id', id)
    // log revision activity
    if (!error && user) {
      await supabase.from('revision_logs').insert([{ user_id: user.id, question_id: id, revised_at: todayLocal() }])
    }
    if (!error) await fetch()
    return error?.message ?? null
  }

  const deleteQuestion = async (id: string) => {
    await supabase.from('questions').delete().eq('id', id)
    await fetch()
  }

  const updateNotes = async (id: string, notes: string) => {
    await supabase.from('questions').update({ notes }).eq('id', id)
    await fetch()
  }

  const updateQuestion = async (id: string, payload: {
    name: string; topic: string; difficulty: string; lc_link: string; notes: string
  }) => {
    const { error } = await supabase.from('questions').update(payload).eq('id', id)
    if (!error) await fetch()
    return error?.message ?? null
  }

  const bulkMarkRevised = async (ids: string[]) => {
    for (const id of ids) {
      const q = questions.find(q => q.id === id)
      if (q) await markRevised(id, q.current_stage)
    }
  }

  return { questions, loading, addQuestion, markRevised, deleteQuestion, updateNotes, updateQuestion, bulkMarkRevised, refetch: fetch }
}