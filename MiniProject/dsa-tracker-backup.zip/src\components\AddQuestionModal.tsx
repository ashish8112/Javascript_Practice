'use client'

import { useState } from 'react'
import { X, Plus, Link, FileText } from 'lucide-react'
import { TOPICS, DIFFICULTY_CONFIG } from '@/types'
import { todayLocal } from '@/lib/dates'

interface Props {
  onAdd: (payload: {
    name: string; topic: string; difficulty: string
    date_solved: string; notes: string; lc_link: string
  }) => Promise<string | null>
  onClose: () => void
}

export default function AddQuestionModal({ onAdd, onClose }: Props) {
  const [name, setName]             = useState('')
  const [topic, setTopic]           = useState('Arrays')
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Medium')
  const [date, setDate]             = useState(todayLocal())
  const [notes, setNotes]           = useState('')
  const [lcLink, setLcLink]         = useState('')
  const [loading, setLoading]       = useState(false)
  const [error, setError]           = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) { setError('Question name is required.'); return }
    setLoading(true)
    const err = await onAdd({ name: name.trim(), topic, difficulty, date_solved: date, notes, lc_link: lcLink })
    setLoading(false)
    if (err) setError(err)
    else onClose()
  }

  return (
    /* Backdrop */
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm"
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      {/* Sheet — slides up from bottom on mobile, centered on desktop */}
      <div className="
        w-full sm:max-w-md
        bg-[#161a23] border border-[#2a3040]
        rounded-t-2xl sm:rounded-2xl
        max-h-[92dvh] sm:max-h-[90vh]
        flex flex-col
        overflow-hidden
      ">

        {/* Drag handle (mobile only) */}
        <div className="flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-10 h-1 rounded-full bg-[#3d4a60]" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#2a3040] flex-shrink-0">
          <h2 className="text-white font-black text-lg">Log New Question</h2>
          <button
            onClick={onClose}
            className="text-[#6b7a99] hover:text-white transition-colors w-8 h-8 flex items-center justify-center rounded-lg hover:bg-[#2a3040]"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scrollable body */}
        <div className="flex-1 overflow-y-auto overscroll-contain">
          <form onSubmit={handleSubmit} className="p-5 space-y-4">

            {/* Question Name */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#6b7a99] mb-2">
                Question Name *
              </label>
              <input
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Two Sum, Merge Intervals…"
                className="w-full bg-[#1e2330] border border-[#2a3040] rounded-xl px-4 py-3.5 text-white text-base outline-none focus:border-blue-500 transition-colors placeholder:text-[#6b7a99]"
                autoFocus
              />
            </div>

            {/* Difficulty — full width buttons */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#6b7a99] mb-2">
                Difficulty
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['Easy', 'Medium', 'Hard'] as const).map(d => (
                  <button
                    key={d} type="button"
                    onClick={() => setDifficulty(d)}
                    className={`rounded-xl py-3 text-sm font-black border transition-all ${
                      difficulty === d
                        ? `${DIFFICULTY_CONFIG[d].bg} ${DIFFICULTY_CONFIG[d].color} ${DIFFICULTY_CONFIG[d].border}`
                        : 'bg-[#1e2330] text-[#6b7a99] border-[#2a3040] hover:border-[#3d4a60]'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* Topic */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#6b7a99] mb-2">
                Topic
              </label>
              <select
                value={topic}
                onChange={e => setTopic(e.target.value)}
                className="w-full bg-[#1e2330] border border-[#2a3040] rounded-xl px-4 py-3.5 text-white text-base outline-none focus:border-blue-500 transition-colors appearance-none"
              >
                {TOPICS.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>

            {/* Date */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#6b7a99] mb-2">
                Date Solved
              </label>
              <input
                type="date"
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-[#1e2330] border border-[#2a3040] rounded-xl px-4 py-3.5 text-white text-base outline-none focus:border-blue-500 transition-colors"
              />
            </div>

            {/* Problem Link */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#6b7a99] mb-2 flex items-center gap-1.5">
                <Link size={11} /> Problem Link
                <span className="normal-case font-normal text-[#4a5570]">(optional)</span>
              </label>
              <input
                value={lcLink}
                onChange={e => setLcLink(e.target.value)}
                placeholder="LeetCode / GFG / CodeChef…"
                className="w-full bg-[#1e2330] border border-[#2a3040] rounded-xl px-4 py-3.5 text-white text-base outline-none focus:border-blue-500 transition-colors placeholder:text-[#6b7a99]"
              />
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-[#6b7a99] mb-2 flex items-center gap-1.5">
                <FileText size={11} /> Notes
                <span className="normal-case font-normal text-[#4a5570]">(optional)</span>
              </label>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                rows={3}
                placeholder="Key insight, time complexity, approach…"
                className="w-full bg-[#1e2330] border border-[#2a3040] rounded-xl px-4 py-3 text-white text-base outline-none focus:border-blue-500 transition-colors placeholder:text-[#6b7a99] resize-none"
              />
            </div>

            {/* Revision schedule preview */}
            <div className="bg-[#1e2330] rounded-xl p-3.5 border border-[#2a3040]">
              <p className="text-[11px] text-[#6b7a99] mb-2.5 font-bold uppercase tracking-wider">
                Auto-scheduled revisions
              </p>
              <div className="grid grid-cols-4 gap-2">
                {[3, 7, 15, 30].map((d, i) => (
                  <div key={d} className="text-center">
                    <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl py-2">
                      <div className="text-blue-400 font-black text-base">+{d}</div>
                      <div className="text-[#6b7a99] text-[10px]">days</div>
                    </div>
                    <div className="text-[#6b7a99] text-[10px] mt-1">Stage {i + 1}</div>
                  </div>
                ))}
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-500 hover:bg-blue-600 active:scale-95 disabled:opacity-50 text-white font-black rounded-xl py-4 transition-all flex items-center justify-center gap-2 text-base"
            >
              {loading
                ? '⏳ Adding…'
                : <><Plus size={18} /> Add to Cloud</>
              }
            </button>

            {/* Bottom padding so content clears mobile nav bar */}
            <div className="h-2" />
          </form>
        </div>
      </div>
    </div>
  )
}