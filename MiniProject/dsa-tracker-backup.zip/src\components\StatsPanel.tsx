'use client'

import { useMemo } from 'react'
import { Question, DIFFICULTY_CONFIG } from '@/types'
import { todayLocal } from '@/lib/dates'
import { Flame, Target, BookOpen, Trophy, TrendingUp } from 'lucide-react'

interface Props {
  questions: Question[]
  streak: number
  totalRevisions: number
}

export default function StatsPanel({ questions, streak, totalRevisions }: Props) {
  const today = todayLocal()

  const stats = useMemo(() => {
    const total    = questions.length
    const due      = questions.filter(q => q.next_revision_date !== 'Completed' && q.next_revision_date <= today).length
    const mastered = questions.filter(q => q.next_revision_date === 'Completed').length
    const inProgress = total - mastered

    const topicMap: Record<string, number> = {}
    questions.forEach(q => { topicMap[q.topic] = (topicMap[q.topic] || 0) + 1 })
    const topTopics = Object.entries(topicMap).sort((a, b) => b[1] - a[1]).slice(0, 6)

    const diffMap = { Easy: 0, Medium: 0, Hard: 0 }
    questions.forEach(q => { diffMap[q.difficulty]++ })

    const masteryPct = total ? Math.round((mastered / total) * 100) : 0

    return { total, due, mastered, inProgress, topTopics, diffMap, masteryPct }
  }, [questions, today])

  return (
    <div className="space-y-3">

      {/* ── Top 4 stats ── */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { icon: Flame,    label: 'Streak',     value: streak,              unit: 'days',     color: 'text-amber-400',  bg: 'bg-amber-400/10',  border: 'border-amber-400/20' },
          { icon: Target,   label: 'Due',        value: stats.due,           unit: 'today',    color: 'text-red-400',    bg: 'bg-red-400/10',    border: 'border-red-400/20' },
          { icon: BookOpen, label: 'Logged',     value: stats.total,         unit: 'questions',color: 'text-blue-400',   bg: 'bg-blue-400/10',   border: 'border-blue-400/20' },
          { icon: Trophy,   label: 'Mastered',   value: stats.mastered,      unit: 'complete', color: 'text-emerald-400',bg: 'bg-emerald-400/10',border: 'border-emerald-400/20' },
        ].map(({ icon: Icon, label, value, unit, color, bg, border }) => (
          <div key={label} className={`${bg} border ${border} rounded-2xl p-4`}>
            <div className="flex items-center gap-2 mb-2">
              <Icon size={15} className={color} />
              <span className={`text-xs font-bold uppercase tracking-wider ${color}`}>{label}</span>
            </div>
            <div className={`text-3xl font-black font-mono ${color}`}>{value}</div>
            <div className="text-[11px] text-[#6b7a99] mt-0.5">{unit}</div>
          </div>
        ))}
      </div>

      {/* ── Mastery progress ── */}
      {stats.total > 0 && (
        <div className="bg-[#161a23] border border-[#2a3040] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#6b7a99] flex items-center gap-1.5">
              <TrendingUp size={12} /> Overall Mastery
            </h3>
            <span className="text-emerald-400 font-black text-sm font-mono">{stats.masteryPct}%</span>
          </div>
          <div className="h-2.5 bg-[#2a3040] rounded-full overflow-hidden mb-3">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 to-emerald-400 transition-all duration-700"
              style={{ width: `${stats.masteryPct}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-[#6b7a99]">
            <span>{stats.mastered} mastered</span>
            <span>{stats.inProgress} in progress</span>
          </div>
        </div>
      )}

      {/* ── Difficulty breakdown ── */}
      {stats.total > 0 && (
        <div className="bg-[#161a23] border border-[#2a3040] rounded-2xl p-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#6b7a99] mb-3">Difficulty Breakdown</h3>
          <div className="space-y-3">
            {(['Easy', 'Medium', 'Hard'] as const).map(d => {
              const count = stats.diffMap[d]
              const pct   = stats.total ? Math.round((count / stats.total) * 100) : 0
              const cfg   = DIFFICULTY_CONFIG[d]
              return (
                <div key={d}>
                  <div className="flex justify-between mb-1.5">
                    <span className={`text-xs font-black ${cfg.color}`}>{d}</span>
                    <span className="text-xs text-[#6b7a99] font-mono">{count} · {pct}%</span>
                  </div>
                  <div className="h-2 bg-[#2a3040] rounded-full overflow-hidden">
                    <div className={`h-full rounded-full transition-all duration-700 ${cfg.dot}`}
                      style={{ width: `${pct}%` }} />
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* ── Top topics ── */}
      {stats.topTopics.length > 0 && (
        <div className="bg-[#161a23] border border-[#2a3040] rounded-2xl p-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#6b7a99] mb-3">Top Topics</h3>
          <div className="space-y-2.5">
            {stats.topTopics.map(([topic, count]) => {
              const pct = stats.total ? Math.round((count / stats.total) * 100) : 0
              return (
                <div key={topic}>
                  <div className="flex justify-between mb-1">
                    <span className="text-xs font-bold text-violet-400">{topic}</span>
                    <span className="text-xs text-[#6b7a99] font-mono">{count}</span>
                  </div>
                  <div className="h-1.5 bg-[#2a3040] rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-violet-500 transition-all duration-700"
                      style={{ width: `${pct}%` }} />
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* ── Revision total ── */}
      <div className="bg-gradient-to-br from-blue-500/10 to-violet-500/10 border border-blue-500/20 rounded-2xl p-4 text-center">
        <div className="text-4xl font-black text-white font-mono">{totalRevisions}</div>
        <div className="text-sm text-[#6b7a99] mt-1 font-semibold">total revisions completed</div>
        <div className="text-[11px] text-[#4a5570] mt-0.5">every revision builds long-term memory 🧠</div>
      </div>
    </div>
  )
}