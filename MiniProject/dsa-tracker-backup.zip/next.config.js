/** @type {import('next').NextConfig} */
const nextConfig = {
  images: { unoptimized: true },
  typescript: { ignoreBuildErrors: false },
  // Exclude Supabase edge functions (Deno) from Next.js TypeScript compilation
  webpack: (config) => {
    config.watchOptions = { ...config.watchOptions, ignored: ['**/supabase/functions/**'] }
    return config
  },
}
module.exports = nextConfig
