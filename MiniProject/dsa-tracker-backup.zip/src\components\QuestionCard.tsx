'use client'

import { useState } from 'react'
import { Question, DIFFICULTY_CONFIG, INTERVALS } from '@/types'
import { formatDate, daysDiff, todayLocal, addDays } from '@/lib/dates'
import { Trash2, ExternalLink, ChevronDown, ChevronUp, FileText, Check, Calendar, Hash, Undo2, Plus, Pencil } from 'lucide-react'
import { supabase } from '@/lib/supabase'

interface Props {
  question: Question
  onRevise: (id: string, stage: number) => void
  onDelete: (id: string) => void
  onEdit: (question: Question) => void
  onUpdateNotes: (id: string, notes: string) => void
  refetch: () => void
}

export default function QuestionCard({ question: q, onRevise, onDelete, onEdit, onUpdateNotes, refetch }: Props) {
  const [expanded, setExpanded]           = useState(false)
  const [editingNotes, setEditingNotes]   = useState(false)
  const [notes, setNotes]                 = useState(q.notes || '')
  const [checking, setChecking]           = useState(false)
  const [justChecked, setJustChecked]     = useState(false)
  const [showExtend, setShowExtend]       = useState(false)
  const [extraDays, setExtraDays]         = useState(7)
  const [extending, setExtending]         = useState(false)
  const [showHistory, setShowHistory]     = useState(false)
  const [history, setHistory]             = useState<string[]>([])
  const [undoing, setUndoing]             = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)

  const today       = todayLocal()
  const isDue       = q.next_revision_date !== 'Completed' && q.next_revision_date <= today
  const isCompleted = q.next_revision_date === 'Completed'
  const diff        = DIFFICULTY_CONFIG[q.difficulty]
  const daysUntil   = isCompleted ? null : daysDiff(q.next_revision_date)
  const stageLabel  = ['1st','2nd','3rd','4th'][q.current_stage] ?? 'Done'

  const handleCheck = async () => {
    if (isCompleted || checking) return
    setChecking(true)
    setJustChecked(true)
    await onRevise(q.id, q.current_stage)
    setChecking(false)
    setJustChecked(false)
  }

  const handleUndo = async () => {
    if (q.current_stage === 0 || undoing) return
    setUndoing(true)
    const prevStage = q.current_stage - 1
    const prevDate  = addDays(today, INTERVALS[prevStage])
    await supabase.from('questions').update({ current_stage: prevStage, next_revision_date: prevDate }).eq('id', q.id)
    const { data } = await supabase.from('revision_logs').select('id').eq('question_id', q.id).order('created_at', { ascending: false }).limit(1)
    if (data?.[0]) await supabase.from('revision_logs').delete().eq('id', data[0].id)
    setUndoing(false)
    refetch()
  }

  const handleExtend = async () => {
    if (!extraDays || extraDays < 1) return
    setExtending(true)
    const base    = q.next_revision_date === 'Completed' ? today : q.next_revision_date
    const newDate = addDays(base, extraDays)
    await supabase.from('questions').update({ next_revision_date: newDate }).eq('id', q.id)
    setExtending(false)
    setShowExtend(false)
    refetch()
  }

  const loadHistory = async () => {
    if (showHistory) { setShowHistory(false); return }
    const { data } = await supabase.from('revision_logs').select('revised_at').eq('question_id', q.id).order('revised_at', { ascending: false })
    setHistory(data?.map(r => r.revised_at) || [])
    setShowHistory(true)
  }

  const handleSaveNotes = async () => {
    await onUpdateNotes(q.id, notes)
    setEditingNotes(false)
  }

  return (
    <div className={`group relative rounded-xl border transition-all duration-200 overflow-hidden
      ${isDue
        ? 'bg-gradient-to-r from-amber-500/5 to-[#1e2330] border-amber-400/40'
        : isCompleted ? 'bg-[#1a1f2a] border-[#2a3040] opacity-55'
        : 'bg-[#1e2330] border-[#2a3040] hover:border-[#3d4a60]'
      }`}>

      {/* Left accent bar */}
      <div className={`absolute left-0 top-0 bottom-0 w-[3px] rounded-l-xl ${
        isCompleted ? 'bg-emerald-500' : isDue ? 'bg-amber-400' : 'bg-transparent group-hover:bg-blue-500/40'
      }`} />

      {/* ── MAIN CONTENT ROW ── */}
      <div className="flex items-start gap-3 px-3 py-3 pl-4">

        {/* Checkbox */}
        <button
          onClick={handleCheck}
          disabled={isCompleted || checking}
          className={`flex-shrink-0 mt-0.5 w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all duration-200
            ${isCompleted
              ? 'bg-emerald-500 border-emerald-500 cursor-default'
              : justChecked ? 'bg-blue-500 border-blue-500 scale-90'
              : isDue ? 'border-amber-400 hover:bg-amber-400/15 cursor-pointer'
              : 'border-[#3d4a60] hover:border-blue-400 cursor-pointer hover:bg-blue-400/10'
            }`}
        >
          {(isCompleted || justChecked)
            ? <Check size={13} className="text-white" strokeWidth={3} />
            : isDue ? <div className="w-1.5 h-1.5 rounded-sm bg-amber-400/70" /> : null
          }
        </button>

        {/* Info — full width, no sibling pushing it */}
        <div className="flex-1 min-w-0">

          {/* Name */}
          <div className="flex items-start gap-2 flex-wrap">
            <span className={`font-bold text-[15px] leading-snug break-words ${isCompleted ? 'line-through text-[#6b7a99]' : 'text-white'}`}>
              {q.name}
            </span>
            {q.lc_link && (
              <a href={q.lc_link} target="_blank" rel="noopener noreferrer"
                onClick={e => e.stopPropagation()}
                className="text-[#6b7a99] hover:text-blue-400 mt-0.5 flex-shrink-0">
                <ExternalLink size={12} />
              </a>
            )}
          </div>

          {/* Difficulty badge */}
          <div className="mt-1.5">
            <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-full border ${diff.bg} ${diff.color} ${diff.border}`}>
              {q.difficulty}
            </span>
          </div>

          {/* Topic + stage */}
          <div className="flex items-center gap-2 mt-1.5">
            <span className="flex items-center gap-1 text-[11px] font-bold text-violet-400 uppercase tracking-wider">
              <Hash size={9} />{q.topic}
            </span>
            {!isCompleted && (
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-[#2a3040] text-[#6b7a99] border border-[#3d4a60]">
                {stageLabel}
              </span>
            )}
          </div>

          {/* Date — full width, no cramping */}
          <div className={`flex items-center gap-1 mt-1 text-[12px] font-semibold font-mono ${
            isCompleted ? 'text-emerald-400' : isDue ? 'text-amber-400' : 'text-[#6b7a99]'
          }`}>
            <Calendar size={10} className="flex-shrink-0" />
            <span>
              {isCompleted ? '🎓 Mastered'
                : isDue ? (daysUntil! < 0 ? `${Math.abs(daysUntil!)}d overdue` : 'Due today')
                : `in ${daysUntil}d · ${formatDate(q.next_revision_date)}`}
            </span>
          </div>

          {/* Stage pips */}
          <div className="flex items-center gap-1 mt-2">
            {INTERVALS.map((_, i) => (
              <div key={i} className="flex items-center gap-0.5">
                <div className={`h-1.5 w-7 rounded-full transition-all duration-500 ${
                  isCompleted ? 'bg-emerald-400' :
                  i < q.current_stage ? 'bg-blue-500' :
                  i === q.current_stage && isDue ? 'bg-amber-400 animate-pulse' :
                  'bg-[#2a3040]'
                }`} />
                {i < INTERVALS.length - 1 && (
                  <span className="text-[7px] text-[#3d4a60] font-mono">+{INTERVALS[i+1] - INTERVALS[i]}</span>
                )}
              </div>
            ))}
            <span className="text-[10px] text-[#6b7a99] ml-1 font-mono">
              {isCompleted ? '4/4' : `${q.current_stage}/4`}
            </span>
          </div>

          {/* ── ACTION BUTTONS — below content on mobile, always visible ── */}
          <div className="flex items-center gap-1.5 mt-2.5 flex-wrap">

            {/* Revised button — only when due */}
            {isDue && !isCompleted && (
              <button onClick={handleCheck} disabled={checking}
                className="flex items-center gap-1 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-400 rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition-all">
                <Check size={11} /> Revised
              </button>
            )}

            {/* Undo */}
            {q.current_stage > 0 && (
              <button onClick={handleUndo} disabled={undoing}
                className="flex items-center gap-1 bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/20 text-amber-400 rounded-lg px-2.5 py-1.5 text-[11px] font-bold transition-all">
                <Undo2 size={11} /> {undoing ? '…' : 'Undo'}
              </button>
            )}

            {/* Icon buttons */}
            <button onClick={loadHistory} title="History"
              className="text-[#6b7a99] hover:text-blue-400 p-1.5 rounded-lg hover:bg-blue-400/10 transition-all">
              <Calendar size={14} />
            </button>
            <button onClick={() => onEdit(q)} title="Edit"
              className="text-[#6b7a99] hover:text-emerald-400 p-1.5 rounded-lg hover:bg-emerald-400/10 transition-all">
              <Pencil size={14} />
            </button>
            <button onClick={() => setShowExtend(!showExtend)} title="Extend"
              className="text-[#6b7a99] hover:text-violet-400 p-1.5 rounded-lg hover:bg-violet-400/10 transition-all">
              <Plus size={14} />
            </button>
            <button onClick={() => setExpanded(!expanded)} title="Notes"
              className="text-[#6b7a99] hover:text-white p-1.5 rounded-lg hover:bg-[#2a3040] transition-all">
              {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>

            {/* Delete with confirm */}
            {confirmDelete ? (
              <div className="flex items-center gap-1 bg-red-500/10 border border-red-500/30 rounded-lg px-2 py-1">
                <span className="text-red-400 text-[11px] font-bold">Sure?</span>
                <button onClick={() => { onDelete(q.id); setConfirmDelete(false) }}
                  className="text-[11px] font-black text-white bg-red-500 rounded px-1.5 py-0.5">Yes</button>
                <button onClick={() => setConfirmDelete(false)}
                  className="text-[11px] text-[#6b7a99] bg-[#2a3040] rounded px-1.5 py-0.5">No</button>
              </div>
            ) : (
              <button onClick={() => setConfirmDelete(true)}
                className="text-[#6b7a99] hover:text-red-400 p-1.5 rounded-lg hover:bg-red-400/10 transition-all">
                <Trash2 size={14} />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ── EXTEND PANEL ── */}
      {showExtend && (
        <div className="mx-4 mb-3 bg-[#161a23] border border-violet-500/30 rounded-xl px-4 py-3">
          <p className="text-xs font-bold text-violet-400 mb-2.5 uppercase tracking-wider">Push next revision by</p>
          <div className="flex gap-2 mb-3 flex-wrap">
            {[3, 7, 14, 30].map(d => (
              <button key={d} onClick={() => setExtraDays(d)}
                className={`text-xs font-bold px-3 py-1.5 rounded-lg border transition-all ${
                  extraDays === d
                    ? 'bg-violet-500/20 border-violet-500/50 text-violet-400'
                    : 'bg-[#1e2330] border-[#2a3040] text-[#6b7a99]'
                }`}>+{d}d</button>
            ))}
            <input type="number" min={1} max={365} value={extraDays}
              onChange={e => setExtraDays(Number(e.target.value))}
              className="w-16 bg-[#1e2330] border border-[#2a3040] rounded-lg px-2 py-1.5 text-white text-xs text-center outline-none focus:border-violet-500"
            />
          </div>
          <div className="flex gap-2">
            <button onClick={handleExtend} disabled={extending}
              className="bg-violet-500 hover:bg-violet-600 disabled:opacity-50 text-white rounded-lg px-4 py-1.5 text-xs font-bold">
              {extending ? 'Saving…' : `Push +${extraDays} days`}
            </button>
            <button onClick={() => setShowExtend(false)}
              className="text-[#6b7a99] bg-[#2a3040] rounded-lg px-3 py-1.5 text-xs font-semibold">
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* ── HISTORY ── */}
      {showHistory && (
        <div className="mx-4 mb-3 bg-[#161a23] border border-[#2a3040] rounded-xl px-4 py-3">
          <p className="text-xs font-bold text-[#6b7a99] mb-2.5 uppercase tracking-wider flex items-center gap-1.5">
            <Calendar size={11} /> Revision History
          </p>
          {history.length === 0
            ? <p className="text-xs text-[#4a5570] italic">No revisions recorded yet.</p>
            : <div className="flex flex-wrap gap-2">
                {history.map((date, i) => (
                  <span key={i} className="text-xs font-mono bg-[#1e2330] border border-[#2a3040] text-[#6b7a99] rounded-lg px-2.5 py-1">
                    {formatDate(date)}
                  </span>
                ))}
              </div>
          }
          <p className="text-[10px] text-[#4a5570] mt-2">First solved: {formatDate(q.date_solved)}</p>
        </div>
      )}

      {/* ── NOTES ── */}
      {expanded && (
        <div className="px-4 pb-4 border-t border-[#2a3040] pt-3 bg-[#161a23]/50">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs text-[#6b7a99] font-semibold flex items-center gap-1.5">
              <FileText size={11} /> Notes & Approach
            </span>
            <span className="text-[10px] text-[#6b7a99] font-mono">Solved: {formatDate(q.date_solved)}</span>
          </div>
          {editingNotes ? (
            <div className="space-y-2">
              <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={4} autoFocus
                className="w-full bg-[#0d0f14] border border-[#2a3040] rounded-xl px-3 py-2.5 text-white text-sm outline-none focus:border-blue-500 resize-none placeholder:text-[#4a5570]"
                placeholder="Approach, key insight, time/space complexity…"
              />
              <div className="flex gap-2">
                <button onClick={handleSaveNotes} className="bg-blue-500 hover:bg-blue-600 text-white rounded-lg px-4 py-1.5 text-xs font-bold">Save</button>
                <button onClick={() => { setEditingNotes(false); setNotes(q.notes || '') }}
                  className="text-[#6b7a99] bg-[#2a3040] rounded-lg px-4 py-1.5 text-xs font-semibold">Cancel</button>
              </div>
            </div>
          ) : (
            <div onClick={() => setEditingNotes(true)}
              className="min-h-[52px] bg-[#0d0f14] border border-dashed border-[#2a3040] rounded-xl px-3 py-2.5 text-sm cursor-pointer hover:border-blue-500/40 transition-colors">
              {notes
                ? <span className="text-[#c4cde0] text-[13px] leading-relaxed whitespace-pre-wrap">{notes}</span>
                : <span className="italic text-[#4a5570] text-[13px]">Click to add approach, key insight, time complexity…</span>
              }
            </div>
          )}
        </div>
      )}
    </div>
  )
}