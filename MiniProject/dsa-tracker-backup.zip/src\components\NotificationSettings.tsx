'use client'

import { useState, useEffect } from 'react'
import { Bell, Mail, Check, Info } from 'lucide-react'
import { supabase } from '@/lib/supabase'
import { useAuth } from '@/hooks/useAuth'

export default function NotificationSettings() {
  const { user } = useAuth()
  const [email, setEmail]       = useState(user?.email || '')
  const [enabled, setEnabled]   = useState(false)
  const [saved, setSaved]       = useState(false)
  const [saving, setSaving]     = useState(false)
  const [loaded, setLoaded]     = useState(false)

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from('notification_settings')
        .select('*')
        .eq('user_id', user?.id)
        .single()
      if (data) { setEmail(data.email); setEnabled(data.enabled) }
      setLoaded(true)
    }
    if (user) load()
  }, [user])

  const handleSave = async () => {
    if (!email || !user) return
    setSaving(true)
    await supabase.from('notification_settings').upsert({
      user_id: user.id,
      email,
      enabled,
      updated_at: new Date().toISOString()
    }, { onConflict: 'user_id' })
    setSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  if (!loaded) return null

  return (
    <div className="bg-[#161a23] border border-[#2a3040] rounded-2xl p-5">
      <div className="flex items-center gap-2.5 mb-4">
        <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
          <Bell size={16} className="text-blue-400" />
        </div>
        <div>
          <h3 className="font-black text-white text-sm">Daily Email Digest</h3>
          <p className="text-[11px] text-[#6b7a99]">Get due questions delivered to your inbox every day at 8 PM</p>
        </div>
      </div>

      {/* Toggle */}
      <div className="flex items-center justify-between mb-4 bg-[#1e2330] border border-[#2a3040] rounded-xl px-4 py-3">
        <div>
          <p className="text-sm font-bold text-white">Enable notifications</p>
          <p className="text-[11px] text-[#6b7a99]">Daily reminder at 8:00 PM IST</p>
        </div>
        <button
          onClick={() => setEnabled(!enabled)}
          className={`relative w-12 h-6 rounded-full transition-all duration-300 ${enabled ? 'bg-blue-500' : 'bg-[#2a3040]'}`}
        >
          <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all duration-300 ${enabled ? 'left-6' : 'left-0.5'}`} />
        </button>
      </div>

      {/* Email input */}
      <div className="mb-4">
        <label className="block text-xs font-bold uppercase tracking-widest text-[#6b7a99] mb-1.5 flex items-center gap-1.5">
          <Mail size={10} /> Notification Email
        </label>
        <input
          type="email" value={email} onChange={e => setEmail(e.target.value)}
          placeholder="your@email.com"
          className="w-full bg-[#1e2330] border border-[#2a3040] rounded-xl px-4 py-3 text-white text-sm outline-none focus:border-blue-500 transition-colors placeholder:text-[#6b7a99]"
        />
        <p className="text-[11px] text-[#6b7a99] mt-1.5">
          Can be different from your login email — e.g. your phone email for quick access
        </p>
      </div>

      {/* What you'll receive */}
      <div className="bg-[#1e2330] border border-[#2a3040] rounded-xl p-3 mb-4">
        <p className="text-[11px] font-bold text-[#6b7a99] uppercase tracking-wider mb-2">Email will contain</p>
        <div className="space-y-1.5">
          {[
            'Number of questions due today',
            'List of each question with topic & difficulty',
            'Direct link to open the app',
            'Sent only when you have questions due',
          ].map((item, i) => (
            <div key={i} className="flex items-start gap-2">
              <Check size={11} className="text-emerald-400 mt-0.5 flex-shrink-0" />
              <span className="text-[12px] text-[#6b7a99]">{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Info note */}
      <div className="flex items-start gap-2 bg-amber-500/5 border border-amber-500/20 rounded-xl px-3 py-2.5 mb-4">
        <Info size={12} className="text-amber-400 mt-0.5 flex-shrink-0" />
        <p className="text-[11px] text-amber-400/80">
          Notifications are sent via a scheduled Supabase Edge Function. Run the SQL below to activate it, then deploy the edge function from the <code className="bg-amber-500/10 px-1 rounded">supabase/functions/</code> folder.
        </p>
      </div>

      <button
        onClick={handleSave} disabled={saving || !email}
        className="w-full bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white font-black rounded-xl py-3 transition-all flex items-center justify-center gap-2 text-sm"
      >
        {saved ? <><Check size={16} /> Saved!</> : saving ? '⏳ Saving…' : <><Bell size={16} /> Save Notification Settings</>}
      </button>
    </div>
  )
}
