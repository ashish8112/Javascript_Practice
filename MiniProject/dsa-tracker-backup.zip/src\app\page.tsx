'use client'

import { useAuth } from '@/hooks/useAuth'
import AuthScreen from '@/components/AuthScreen'
import Dashboard from '@/components/Dashboard'
import { Zap } from 'lucide-react'

export default function Home() {
  const { user, loading } = useAuth()

  if (loading) return (
    <div className="min-h-screen bg-[#0d0f14] flex items-center justify-center">
      <div className="flex items-center gap-3 text-white animate-pulse">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-violet-500 flex items-center justify-center">
          <Zap size={18} className="text-white" />
        </div>
        <span className="font-black text-xl font-mono">DSA<span className="text-blue-400">Tracker</span></span>
      </div>
    </div>
  )

  return user ? <Dashboard /> : <AuthScreen />
}
