-- ── 1. Notification settings table ──────────────────────────
CREATE TABLE IF NOT EXISTS public.notification_settings (
  id         UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id    UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  email      TEXT NOT NULL,
  enabled    BOOLEAN DEFAULT true,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc', now())
);

ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own notification settings"
  ON public.notification_settings FOR ALL
  USING (auth.uid() = user_id);

-- ── 2. Schedule daily digest at 8 PM IST (14:30 UTC) ────────
-- Requires pg_cron extension (enabled by default on Supabase)
SELECT cron.schedule(
  'daily-dsa-digest',
  '30 14 * * *',   -- 14:30 UTC = 8:00 PM IST every day
  $$
    SELECT net.http_post(
      url := 'https://YOUR-PROJECT-ID.supabase.co/functions/v1/daily-digest',
      headers := '{"Authorization": "Bearer YOUR-ANON-KEY"}'::jsonb
    );
  $$
);
-- Replace YOUR-PROJECT-ID and YOUR-ANON-KEY above before running
