'use client'

import { useEffect, useState } from 'react'

interface ToastProps {
  message: string
  type?: 'success' | 'error' | 'info'
  onClose: () => void
}

export function Toast({ message, type = 'success', onClose }: ToastProps) {
  useEffect(() => {
    const t = setTimeout(onClose, 3000)
    return () => clearTimeout(t)
  }, [onClose])

  const colors = {
    success: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
    error: 'bg-red-500/10 border-red-500/30 text-red-400',
    info: 'bg-blue-500/10 border-blue-500/30 text-blue-400',
  }

  return (
    <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-50 border rounded-xl px-5 py-3 text-sm font-semibold whitespace-nowrap shadow-2xl ${colors[type]} backdrop-blur-sm animate-in slide-in-from-bottom-4`}>
      {message}
    </div>
  )
}

// Toast manager hook
import { useCallback } from 'react'
interface ToastState { message: string; type: 'success' | 'error' | 'info'; id: number }

export function useToast() {
  const [toasts, setToasts] = useState<ToastState[]>([])
  const counterRef = { current: 0 }

  const show = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = ++counterRef.current
    setToasts(t => [...t, { message, type, id }])
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const remove = useCallback((id: number) => {
    setToasts(t => t.filter(x => x.id !== id))
  }, [])

  const ToastContainer = () => (
    <>
      {toasts.map(t => (
        <Toast key={t.id} message={t.message} type={t.type} onClose={() => remove(t.id)} />
      ))}
    </>
  )

  return { show, ToastContainer }
}
