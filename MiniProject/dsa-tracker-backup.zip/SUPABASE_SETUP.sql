-- ════════════════════════════════════════════
--  DSA TRACKER — Full Supabase Schema
--  Run this entire file in Supabase SQL Editor
-- ════════════════════════════════════════════

-- 1. Questions table
create table if not exists public.questions (
  id                 uuid default gen_random_uuid() primary key,
  user_id            uuid references auth.users(id) on delete cascade not null,
  name               text not null,
  topic              text not null,
  difficulty         text not null default 'Medium',
  date_solved        date not null,
  notes              text,
  lc_link            text,
  current_stage      integer default 0,
  next_revision_date text not null,
  created_at         timestamp with time zone default timezone('utc', now()) not null
);

alter table public.questions enable row level security;

create policy "Users manage own questions"
  on public.questions for all
  using (auth.uid() = user_id);

-- 2. Revision activity log (for heatmap + streak)
create table if not exists public.revision_logs (
  id          uuid default gen_random_uuid() primary key,
  user_id     uuid references auth.users(id) on delete cascade not null,
  question_id uuid references public.questions(id) on delete cascade not null,
  revised_at  date not null default current_date,
  created_at  timestamp with time zone default timezone('utc', now()) not null
);

alter table public.revision_logs enable row level security;

create policy "Users manage own logs"
  on public.revision_logs for all
  using (auth.uid() = user_id);

-- ════════════════════════════════════════════
--  GOOGLE OAUTH SETUP (In Supabase Dashboard)
--  Authentication → Providers → Google → Enable
--  Add your Google OAuth Client ID + Secret
--  Redirect URL: https://YOUR-PROJECT.supabase.co/auth/v1/callback
-- ════════════════════════════════════════════
