'use client'

import { getLast365Days } from '@/lib/dates'

interface Props {
  activityMap: Record<string, number>
}

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

export default function ActivityHeatmap({ activityMap }: Props) {
  const days = getLast365Days()

  // pad to start from Sunday
  const firstDay = new Date(days[0])
  const startPad = firstDay.getDay() // 0=Sun
  const paddedDays = [...Array(startPad).fill(null), ...days]

  const getIntensity = (count: number) => {
    if (count === 0) return 'bg-[#1e2330] border-[#2a3040]'
    if (count === 1) return 'bg-blue-900/60 border-blue-800/40'
    if (count === 2) return 'bg-blue-700/70 border-blue-600/40'
    if (count === 3) return 'bg-blue-500/80 border-blue-400/40'
    return 'bg-blue-400 border-blue-300/40'
  }

  // build weeks (columns of 7)
  const weeks: (string | null)[][] = []
  for (let i = 0; i < paddedDays.length; i += 7) {
    weeks.push(paddedDays.slice(i, i + 7))
  }

  // month labels
  const monthLabels: { label: string; col: number }[] = []
  let lastMonth = -1
  weeks.forEach((week, wi) => {
    const firstReal = week.find(d => d !== null)
    if (firstReal) {
      const m = parseInt(firstReal.split('-')[1]) - 1
      if (m !== lastMonth) { monthLabels.push({ label: MONTHS[m], col: wi }); lastMonth = m }
    }
  })

  return (
    <div className="overflow-x-auto">
      {/* Month labels */}
      <div className="flex gap-[3px] mb-1 pl-0">
        {weeks.map((_, wi) => {
          const lbl = monthLabels.find(m => m.col === wi)
          return (
            <div key={wi} className="w-[11px] text-[9px] text-[#6b7a99] flex-shrink-0">
              {lbl ? lbl.label : ''}
            </div>
          )
        })}
      </div>
      {/* Grid */}
      <div className="flex gap-[3px]">
        {weeks.map((week, wi) => (
          <div key={wi} className="flex flex-col gap-[3px]">
            {week.map((day, di) => {
              if (!day) return <div key={di} className="w-[11px] h-[11px]" />
              const count = activityMap[day] || 0
              return (
                <div
                  key={di}
                  title={`${day}: ${count} revision${count !== 1 ? 's' : ''}`}
                  className={`w-[11px] h-[11px] rounded-[2px] border transition-all cursor-pointer hover:scale-125 ${getIntensity(count)}`}
                />
              )
            })}
          </div>
        ))}
      </div>
      {/* Legend */}
      <div className="flex items-center gap-1.5 mt-2 justify-end">
        <span className="text-[10px] text-[#6b7a99]">Less</span>
        {['bg-[#1e2330]', 'bg-blue-900/60', 'bg-blue-700/70', 'bg-blue-500/80', 'bg-blue-400'].map((c, i) => (
          <div key={i} className={`w-[10px] h-[10px] rounded-[2px] ${c}`} />
        ))}
        <span className="text-[10px] text-[#6b7a99]">More</span>
      </div>
    </div>
  )
}
