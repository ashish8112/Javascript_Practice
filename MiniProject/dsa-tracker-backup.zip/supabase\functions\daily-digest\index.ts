// @ts-nocheck
// Supabase Edge Function (Deno runtime)

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

serve(async () => {
  try {
    const SUPABASE_URL   = Deno.env.get('SUPABASE_URL')!
    const SUPABASE_KEY   = Deno.env.get('SERVICE_ROLE_KEY')!
    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')!
    const APP_URL        = Deno.env.get('APP_URL') || 'https://dsatracker-ashish.vercel.app'

    const db = createClient(SUPABASE_URL, SUPABASE_KEY)

    const today = new Date().toISOString().split('T')[0]

    // Get all users with notifications enabled
    const { data: settings, error: settingsError } = await db
      .from('notification_settings')
      .select('user_id, email')
      .eq('enabled', true)

    if (settingsError) {
      return new Response(JSON.stringify({ error: settingsError.message }), { status: 500 })
    }

    if (!settings || settings.length === 0) {
      return new Response(JSON.stringify({ sent: 0, reason: 'no subscribers' }), { status: 200 })
    }

    let sent = 0
    const results = []

    for (const setting of settings) {
      // Get due questions for this user
      const { data: due, error: dueError } = await db
        .from('questions')
        .select('name, topic, difficulty, next_revision_date, current_stage')
        .eq('user_id', setting.user_id)
        .lte('next_revision_date', today)
        .neq('next_revision_date', 'Completed')
        .order('next_revision_date', { ascending: true })

      if (dueError || !due || due.length === 0) {
        results.push({ email: setting.email, skipped: true, reason: dueError?.message || 'no due questions' })
        continue
      }

      const diffColor = { Easy: '#34d399', Medium: '#fbbf24', Hard: '#f87171' }

      const questionRows = due.map(q => `
        <tr style="border-bottom:1px solid #2a3040">
          <td style="padding:10px 12px;color:#e8ecf4;font-size:14px;font-weight:600">${q.name}</td>
          <td style="padding:10px 12px;color:#a78bfa;font-size:12px;text-transform:uppercase">${q.topic}</td>
          <td style="padding:10px 12px">
            <span style="background:${diffColor[q.difficulty]}22;color:${diffColor[q.difficulty]};border:1px solid ${diffColor[q.difficulty]}44;border-radius:20px;padding:2px 10px;font-size:11px;font-weight:700">
              ${q.difficulty}
            </span>
          </td>
          <td style="padding:10px 12px;color:#6b7a99;font-size:12px;font-family:monospace">Stage ${q.current_stage + 1}/4</td>
        </tr>
      `).join('')

      const html = `<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#0d0f14;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
  <div style="max-width:560px;margin:0 auto;padding:32px 16px">
    <div style="text-align:center;margin-bottom:28px">
      <span style="background:#161a23;border:1px solid #2a3040;border-radius:12px;padding:10px 20px;color:#e8ecf4;font-size:18px;font-weight:900">
        ⚡ DSA<span style="color:#5b8cff">Tracker</span>
      </span>
    </div>
    <div style="background:#161a23;border:1px solid #2a3040;border-radius:16px;overflow:hidden">
      <div style="background:linear-gradient(135deg,#5b8cff22,#a78bfa22);border-bottom:1px solid #2a3040;padding:20px 24px">
        <h1 style="margin:0 0 4px;color:#e8ecf4;font-size:20px;font-weight:900">🔥 ${due.length} Question${due.length > 1 ? 's' : ''} Due Today</h1>
        <p style="margin:0;color:#6b7a99;font-size:13px">${new Date().toLocaleDateString('en-IN', { weekday:'long', day:'numeric', month:'long', year:'numeric' })}</p>
      </div>
      <table style="width:100%;border-collapse:collapse">
        <thead>
          <tr style="background:#1e2330">
            <th style="padding:8px 12px;text-align:left;color:#6b7a99;font-size:10px;text-transform:uppercase">Question</th>
            <th style="padding:8px 12px;text-align:left;color:#6b7a99;font-size:10px;text-transform:uppercase">Topic</th>
            <th style="padding:8px 12px;text-align:left;color:#6b7a99;font-size:10px;text-transform:uppercase">Difficulty</th>
            <th style="padding:8px 12px;text-align:left;color:#6b7a99;font-size:10px;text-transform:uppercase">Stage</th>
          </tr>
        </thead>
        <tbody>${questionRows}</tbody>
      </table>
      <div style="padding:20px 24px;border-top:1px solid #2a3040;text-align:center">
        <a href="${APP_URL}" style="display:inline-block;background:#5b8cff;color:white;text-decoration:none;font-weight:800;font-size:14px;padding:12px 32px;border-radius:12px">
          Open DSATracker →
        </a>
        <p style="margin:12px 0 0;color:#6b7a99;font-size:11px">Daily digest from DSATracker · Spaced Repetition for Coders</p>
      </div>
    </div>
  </div>
</body>
</html>`

      // Send via Resend — fully awaited
      const resendRes = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${RESEND_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: 'DSATracker <onboarding@resend.dev>',
          to: [setting.email],
          subject: `🔥 ${due.length} DSA question${due.length > 1 ? 's' : ''} due today`,
          html,
        }),
      })

      const resendData = await resendRes.json()
      results.push({ email: setting.email, status: resendRes.status, resend: resendData })

      if (resendRes.ok) sent++
    }

    return new Response(
      JSON.stringify({ sent, results }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    )

  } catch (err) {
    return new Response(
      JSON.stringify({ error: String(err) }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    )
  }
})