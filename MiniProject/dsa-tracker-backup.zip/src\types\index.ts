export type Difficulty = 'Easy' | 'Medium' | 'Hard'

export type Topic =
  | 'Arrays' | 'Strings' | 'HashMap' | 'Binary Search'
  | 'Linked List' | 'Stacks & Queues' | 'Trees' | 'Graphs'
  | 'Recursion' | 'DP' | 'Greedy' | 'Backtracking'
  | 'Sorting' | 'Math' | 'Sliding Window' | 'Two Pointers'
  | 'Bit Manipulation' | 'Heap' | 'Trie' | 'Segment Tree'

export interface Question {
  id: string
  user_id: string
  name: string
  topic: Topic
  difficulty: Difficulty
  date_solved: string
  notes: string | null
  lc_link: string | null
  current_stage: number
  next_revision_date: string
  created_at: string
}

export interface RevisionLog {
  id: string
  user_id: string
  question_id: string
  revised_at: string
}

export const INTERVALS = [3, 7, 15, 30] as const

export const TOPICS: Topic[] = [
  'Arrays', 'Strings', 'HashMap', 'Binary Search',
  'Linked List', 'Stacks & Queues', 'Trees', 'Graphs',
  'Recursion', 'DP', 'Greedy', 'Backtracking',
  'Sorting', 'Math', 'Sliding Window', 'Two Pointers',
  'Bit Manipulation', 'Heap', 'Trie', 'Segment Tree'
]

export const DIFFICULTY_CONFIG = {
  Easy:   { color: 'text-emerald-400', bg: 'bg-emerald-400/10', border: 'border-emerald-400/30', dot: 'bg-emerald-400' },
  Medium: { color: 'text-amber-400',   bg: 'bg-amber-400/10',   border: 'border-amber-400/30',   dot: 'bg-amber-400' },
  Hard:   { color: 'text-red-400',     bg: 'bg-red-400/10',     border: 'border-red-400/30',     dot: 'bg-red-400' },
}
