'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { todayLocal, getLast365Days } from '@/lib/dates'
import { useAuth } from './useAuth'

export function useActivity() {
  const { user } = useAuth()
  const [activityMap, setActivityMap] = useState<Record<string, number>>({})
  const [streak, setStreak] = useState(0)
  const [totalRevisions, setTotalRevisions] = useState(0)

  useEffect(() => {
    if (!user) return
    const load = async () => {
      const { data } = await supabase
        .from('revision_logs')
        .select('revised_at')
        .order('revised_at', { ascending: false })

      if (!data) return
      const map: Record<string, number> = {}
      data.forEach(r => { map[r.revised_at] = (map[r.revised_at] || 0) + 1 })
      setActivityMap(map)
      setTotalRevisions(data.length)

      // calculate streak
      let s = 0
      const today = todayLocal()
      const days = getLast365Days().reverse()
      for (const day of days) {
        if (day > today) continue
        if (map[day]) s++
        else if (day !== today) break
      }
      setStreak(s)
    }
    load()
  }, [user])

  return { activityMap, streak, totalRevisions }
}
